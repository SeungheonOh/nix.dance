module Lib (someFunc) where

someFunc :: IO ()
someFunc = putStrLn "Hello 世界"
